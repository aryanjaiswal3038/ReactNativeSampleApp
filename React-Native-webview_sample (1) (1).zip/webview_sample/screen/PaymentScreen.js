import React, { Component } from 'react';
import { StyleSheet, Text, View , Button, Linking,  BackHandler, Platform, ActivityIndicator} from 'react-native';
import { WebView } from 'react-native-webview';


export default class PaymentScreen extends Component {

 constructor(props) {
    super(props);
  }

  webView = {
    canGoBack: false,
    ref: null,
  }

  onAndroidBackPress = () => {
    if (this.webView.canGoBack && this.webView.ref) {
      this.webView.ref.goBack();
      return true;
    }
    return false;
  }

  componentWillMount() {
    if (Platform.OS === 'android') {
      BackHandler.addEventListener('hardwareBackPress', this.onAndroidBackPress);
    }
  }

  componentWillUnmount() {
    if (Platform.OS === 'android') {
      BackHandler.removeEventListener('hardwareBackPress');
    }
  }

  onNavigationStateChange = (navState) => {
    this.webView.canGoBack = navState.canGoBack;
    if (navState.url == 'https://payu.herokuapp.com/success') {
      console.log('finish');
      this.props.navigation.goBack();
    }else if (navState.url == 'https://payu.herokuapp.com/failure') {
      console.log('finish');
      this.props.navigation.goBack();
    }
  };


  onShouldStartLoadWithRequest(request) {
      // short circuit these
      if (
        !request.url ||
        request.url.startsWith('upi://pay?')
      ) 
      {
        console.log('request.url true');
        return true;
      }

      // let everything else to the webview
       console.log('webview true'+request.url);
      return true;
    }


  render() {
    return <WebView source={{ 
        uri: this.props.route.params.url, // Pass the PayU Payment URL
        method: 'POST',
        headers: {
        'Content-Type': 'application/json',
        },
        body: this.props.route.params.postData}} // Pass the Post-Data
        startInLoadingState={true}
        scalesPageToFit={true}
        javaScriptEnabledAndroid={true}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        useWebKit={true}
        // originWhitelist={['*']} //It gives an error UNKNOWN_URL_SCHEME
        allowsBackForwardNavigationGestures={false}
        onShouldStartLoadWithRequest={this.onShouldStartLoadWithRequest.bind(this,)}
        ref={(webView) => { this.webView.ref = webView; }}
        onNavigationStateChange={this.onNavigationStateChange}
        // onNavigationStateChange={(navState) => { this.webView.canGoBack = navState.canGoBack; }}
        onMessage={event => {
          alert('MESSAGE >>>>' + event.nativeEvent.data);
        }}
        onLoadStart={() => {
          console.log("LOAD START ");
        }}
        onLoadEnd={() => {
          console.log('LOAD END');
        }}
        onError={err => {
          console.log('ERROR ');
          console.log(err);
        }}
      />;
  }
}