 import React, { useState, useEffect } from 'react';
 import { Platform, StyleSheet, Text, TextInput, View, Button, NativeModules, Alert, Switch, ScrollView, PermissionsAndroid, DeviceEventEmitter, NativeEventEmitter } from 'react-native';
 import { sha512 } from 'js-sha512';
 const { PayUBizSdk } = NativeModules;
 import PaymentScreen from './PaymentScreen';

import { useNavigation } from '@react-navigation/native';


 export default HomeScreen= () => {
 
     const navigation = useNavigation();
     const [key, setKey] = useState('gtKFFx');
     const [amount, setAmount] = useState("10");
     const [productInfo, setProductInfo] = useState('productInfo');
     const [firstName, setFirstName] = useState('firstName');
     const [email, setEmail] = useState('test@gmail.com');
     const [phone, setPhone] = useState('9999999999');
     const [ios_surl, setIosSurl] = useState('https://payu.herokuapp.com/ios_success');
     const [ios_furl, setIosFurl] = useState('https://payu.herokuapp.com/ios_failure');
 
     const [environment, setEnvironment] = useState(1 + "");
     const [android_surl, setAndroidSurl] = useState('https://payu.herokuapp.com/success');
     const [android_furl, setAndroidFurl] = useState('https://payu.herokuapp.com/failure');
   
     const [merchantSalt, setMerchantSalt] = useState('4R38IvwiV57FwVpsgOvTXBdLE4tHUXFW');
 
     const [userCredential, setUserCredential] = useState('umang:arya');
 
     const [showAlert, setShowAlert] = useState(false);
 
     displayAlert = (title, value) => {
         if (showAlert == false) {
             console.log('displayAlert ' + title + ' ' + value);
             setShowAlert(true);
             Alert.alert(title, value);
 
         }
         setShowAlert(false);
     }
     
     //Used to send back hash generated to SDK
     sendBackHash = (hashName, hashData) => {
         console.log(hashName);
         var hashValue = calculateHash(hashData);
         var result = { [hashName]: hashValue };
         console.log(result);
         PayUBizSdk.hashGenerated(result);
     }

     calculateHash = (data) => {
         console.log(data);
         var result = sha512(data);
         console.log(result);
         return result;
     }

     launchPayU = () => {
      
          
         var txnid = new Date().getTime().toString();

         //Hash Data Formula
         var hashData = `${key}|${txnid}|${amount}|${productInfo}|${firstName}|${email}|||||||||||`;

         var hashValue = calculateHash(hashData+merchantSalt);
         
         //Create Post Data
         var postData = `key=${key}&txnid=${txnid}&amount=${amount}&firstname=${firstName}&email=${email}&phone=${phone}&productinfo=${productInfo}&surl=${android_surl}&furl=${android_furl}&hash=${hashValue}`;
         
        
         var url = 'https://test.payu.in/_payment';

         if (environment == 0) {
            url = 'https://secure.payu.in/_payment'
         }

         //Pass the data from HomeScreen to PaymentScreen
         navigation.navigate('PaymentScreen', { 'postData': postData, 'url' : url}); 

     }
     return (
         <ScrollView style={styles.container}>
             <View >
             <Text style={styles.welcome}>☆ WebView React-Native ☆{'\n'}Sample App</Text> 
             </View> 
             <View style={styles.cell}>
                 <Text style={styles.category}>Merchant Key</Text>
                 <TextInput style={styles.valuesTextInput} defaultValue={key} onChangeText={text => { setKey(text)}} />
             </View>
             <View style={styles.cell}>
                 <Text style={styles.category}>Merchant Salt</Text>
                 <TextInput style={styles.valuesTextInput} defaultValue={merchantSalt} onChangeText={text => { setMerchantSalt(text) }} />
             </View>
             <View style={styles.cell}>
                 <Text style={styles.category}>Environment</Text>
                 <TextInput style={styles.valuesTextInput} defaultValue={environment} onChangeText={text => { setEnvironment(text) }} />
             </View>
             <View style={styles.cell}>
                 <Text style={styles.category}>Enter Transcation{'\n'}Amount</Text>
                 <TextInput style={styles.valuesTextInput} defaultValue={amount} onChangeText={text => { setAmount(text) }} />
             </View>
             <View style={styles.cell}>
                 <Text style={styles.category}>Email</Text>
                 <TextInput style={styles.valuesTextInput} defaultValue={email} onChangeText={text => { setEmail(text) }} />
             </View>
             <View style={styles.cell}>
                 <Text style={styles.category}>User Credential</Text>
                 <TextInput style={styles.valuesTextInput} defaultValue={userCredential} onChangeText={text => { setUserCredential(text) }} />
             </View>
             
            <View style={styles.button}>
             <Button title={'Pay Now'}  onPress={()=>{launchPayU()}} />
            </View>
         </ScrollView>
     );
 }
 
 const styles = StyleSheet.create({
     contentContainerStyle: {
         flex: 2,
         justifyContent: 'center',
         alignItems: 'center',
         backgroundColor: '#F5FCFF',
 
     },
     welcome: {
         fontSize: 20,
         textAlign: 'center',
         margin: 10,
         marginTop: 10,
         marginBottom: 20,
         padding:10,
         backgroundColor: '#6495DD',
         fontWeight:"bold"  
     },
     category: {
         fontSize: 14,
         textAlign: 'left',
         fontWeight: "bold"
     },
     values: {
         fontSize: 14,
         textAlign: 'right'
     },
     valuesTextInput: {
        fontSize: 14,
        textAlign: 'right',
        width:180,
        borderWidth: .5,
        borderRadius: 5,
        padding: 10,
        backgroundColor:'#F2F3F4'
    },
     valuesSwitch: {
        fontSize: 14,
        textAlign: 'right'
    },
     instructions: {
         textAlign: 'center',
         color: '#333333',
         marginBottom: 5,
     },
     button: {
         margin: 10,
     },
     cell: {
         flex: 1,
         flexDirection: 'row',
         justifyContent: 'space-between',
         alignItems: 'center',
         margin: 10,
     },
 });