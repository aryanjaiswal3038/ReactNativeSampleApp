import React, { Component } from 'react';
import { StyleSheet, Text, View , Button, Linking,  BackHandler, Platform, ActivityIndicator} from 'react-native';
import { WebView } from 'react-native-webview';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screen/HomeScreen';
import PaymentScreen from './screen/PaymentScreen';

const Stack = createStackNavigator();

function NavStack() {
  return (
     <Stack.Navigator
        screenOptions={{
          headerTitleAlign: 'center',
          headerStyle: {
            backgroundColor: '#621FF7',
          },
          headerTintColor: '#fff',
          headerTitleStyle :{
            fontWeight: 'bold',
          },
        }}
      >
      <Stack.Screen 
        name="HomeScreen" 
        component={HomeScreen} 
        options={{ title: 'HomeScreen' }, {headerShown: false}}
      />
      <Stack.Screen 
        name="PaymentScreen" 
        component={PaymentScreen} 
        options={{ title: 'PaymentScreen' }, {headerShown: false}}
      />
    </Stack.Navigator>
  );
}
export default function App() {
  return (
    <NavigationContainer>
      <NavStack />
    </NavigationContainer>
  );
}




